import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
const db = new DatabaseSync(new URL('./legacy.sqlite', import.meta.url).pathname);
db.exec('PRAGMA foreign_keys=ON');
function send(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(body));}
function settle(id,res){
 const order=db.prepare('SELECT * FROM orders WHERE id=?').get(id);
 if(!order)return send(res,404,{code:'ORDER_NOT_FOUND'});
 if(order.status!=='PAID')return send(res,409,{code:'ORDER_NOT_PAID',status:order.status});
 if(db.prepare('SELECT id FROM settlements WHERE order_id=?').get(id))return send(res,409,{code:'ALREADY_SETTLED'});
 const fee=Math.ceil(order.gross_amount*order.commission_bps/10000);
 const net=order.gross_amount-fee;
 db.exec('BEGIN IMMEDIATE');
 try {
  const result=db.prepare('INSERT INTO settlements(order_id,gross_amount,fee_amount,net_amount) VALUES(?,?,?,?)').run(id,order.gross_amount,fee,net);
  db.prepare('UPDATE orders SET settled_at=CURRENT_TIMESTAMP WHERE id=?').run(id);
  db.prepare('INSERT INTO audit_log(event,order_id,detail) VALUES(?,?,?)').run('SETTLE_ORDER',id,JSON.stringify({settlement_id:Number(result.lastInsertRowid),fee,net}));
  db.exec('COMMIT');
  return send(res,201,{settlement_id:Number(result.lastInsertRowid),order_id:id,gross_amount:order.gross_amount,fee_amount:fee,net_amount:net});
 } catch(error){db.exec('ROLLBACK');return send(res,500,{code:'SETTLEMENT_FAILED'});}
}
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://127.0.0.1').pathname;
 if(req.method==='GET'&&path==='/api/orders')return send(res,200,db.prepare('SELECT o.*,c.name AS customer_name FROM orders o JOIN customers c ON c.id=o.customer_id ORDER BY o.id').all());
 if(req.method==='GET'&&path==='/api/settlements')return send(res,200,db.prepare('SELECT * FROM settlements ORDER BY id').all());
 if(req.method==='GET'&&path==='/api/audit')return send(res,200,db.prepare('SELECT * FROM audit_log ORDER BY id').all());
 const match=path.match(/^\/api\/orders\/(\d+)\/settle$/);
 if(req.method==='POST'&&match)return settle(Number(match[1]),res);
 if(req.method==='GET'&&(path==='/'||path==='/app.js')){
  const file=path==='/'?'index.html':'app.js';
  res.writeHead(200,{'Content-Type':path==='/'?'text/html; charset=utf-8':'text/javascript; charset=utf-8'});
  return res.end(readFileSync(new URL('./public/'+file,import.meta.url)));
 }
 return send(res,404,{code:'NOT_FOUND'});
});
server.listen(Number(process.env.PORT||4318),'127.0.0.1',()=>console.log(JSON.stringify({ready:true,url:'http://127.0.0.1:'+server.address().port})));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{db.close();process.exit(0);}));
