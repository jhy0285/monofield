# REA SI handover — 실제 실행 번들

[결과 보고서](HANDOVER.md)를 먼저 읽으세요. 대상은 합성 주문·정산 시스템이며, 실제 REA와 MonoField CLI를 실행한 결과입니다.

## 산출물

- `deliverables/interface-spec.xlsx`, `interface-spec.json`, `interface-spec.html`
- `deliverables/screen-spec.pptx`, `screen-spec.json`, `screen-spec.html`
- `deliverables/overview.png`, `rea-browser.png`: REA 실제 캡처
- `evidence/`: REA 원본 JSON, 문서 CLI 결과·경고, 검증 결과
- `fixture-source/prepare.ts`: 데모 대상 생성기. REA 입력과 분리했습니다.
- `collect-documents.ts`: 실제 REA 근거를 읽고 검증해 MonoField 계약에 맞춰 문서를 작성하는 데모용 agent collector
- `run-demo.ts`: 새 디렉터리에서 실행하는 재현기

## 재현

Node 24.15 이상, Chromium, 빌드된 REA와 MonoField가 필요합니다. 이번 실행은 Node 24.19.0을 사용했습니다. 기본 브라우저 경로는 `/usr/bin/chromium`이며 다른 환경에서는 `browser-scenario.json`과 `browser-overview.json`의 `executable_path`를 바꾸세요. 네이티브 분석 엔진이나 LLM API 키는 이 조사에 필요하지 않습니다.

REA의 실행 버전은 `jhy0285/rea-yj` commit `bb540826d65316c164d2de8ba4ef10f81a8ad073`입니다. 해당 저장소에서:

```bash
HUSKY=0 npx -y npm@11.16.0 ci
npx -y npm@11.16.0 run build:cached
```

MonoField 저장소에서:

```bash
npx -y pnpm@10.33.2 --filter @open-design/contracts build
npx -y pnpm@10.33.2 --filter @open-design/daemon build
```

이 번들 디렉터리에서 절대 경로를 지정해 실행하세요. 마지막 경로는 **아직 존재하지 않는 디렉터리**여야 합니다.

```bash
node run-demo.ts /absolute/path/to/rea-yj /absolute/path/to/monofield /absolute/path/to/new-run
```

재현기는 합성 앱을 빈 포트에 실행하고 실제 REA의 정적 분석·SQLite 검사·Chromium 시나리오를 수행합니다. 수집한 결과를 검증한 후 MonoField docs CLI로 Excel/PPTX 및 HTML을 출력하고, 자신이 시작한 앱을 종료합니다. npm 설정이나 MCP 등록을 바꾸지 않습니다. 재현 결과는 새 디렉터리에 별도 보관되므로 최초 보고서의 Evidence ID·시각·포트와 달라질 수 있습니다.

기존 문서 JSON만 다시 출력하려면:

```bash
node /absolute/path/to/monofield/apps/daemon/bin/monofield.mjs docs render-interface-spec --input deliverables/interface-spec.json --out deliverables/interface-spec.xlsx
node /absolute/path/to/monofield/apps/daemon/bin/monofield.mjs docs render-screen-spec --input deliverables/screen-spec.json --out deliverables/screen-spec.pptx
```

이 번들은 제품 내 REA 자동 연결 기능을 추가하지 않습니다. 실측 근거 수집부터 검토용 인수인계 산출물까지 가능한지를 실행한 데모입니다. 운영 시스템 조사에는 대상별 허용 작업·데이터·환경에 맞춘 시나리오와 collector가 필요합니다.
