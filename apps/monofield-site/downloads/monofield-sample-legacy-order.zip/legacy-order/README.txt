MonoField 처음 시작하기 예제 (legacy-order)

회원 가입과 주문 API가 있는 작은 Spring 프로젝트입니다.
따라 하는 방법: https://github.com/jhy0285/monofield/blob/main/docs/getting-started.ko.md

1. 이 폴더에서 명령 프롬프트를 열고: git init / git add -A / git commit -m "baseline"
2. MonoField 홈 > 작업 폴더 선택 > 이 폴더
3. 용어 사전: docs/term-dictionary.csv
