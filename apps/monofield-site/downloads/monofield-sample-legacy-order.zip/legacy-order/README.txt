MonoField 처음 시작하기 예제 (legacy-order)

회원 가입과 주문 API가 있는 작은 Spring 프로젝트입니다.
따라 하는 방법: https://github.com/jhy0285/monofield/blob/main/docs/getting-started.ko.md

1. 이 폴더에서 명령 프롬프트를 열고: git init / git add -A / git commit -m "baseline"
2. MonoField 홈 > 작업 폴더 선택 > 이 폴더
3. 용어 사전: docs/term-dictionary.csv
4. 참고: 이 예제는 구조를 읽고 문서를 맞추는 연습용이라 서비스 로직이 비어 있습니다. 실행 버튼으로 앱이 뜨는 것까지만 확인하세요(API를 부르면 'demo fixture' 오류가 나는 것이 정상입니다). 토큰 검증 주소(jwk-set-uri)도 가짜 주소입니다.
